#pragma once
#ifndef __Point2Predeclaration_hpp__
#define __Point2Predeclaration_hpp__


namespace Geometry {
	template<typename T>
	class Point2;
}


#endif