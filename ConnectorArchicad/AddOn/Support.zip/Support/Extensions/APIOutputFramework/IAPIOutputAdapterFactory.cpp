
#include "IAPIOutputAdapterFactory.hpp"

GSAPI::IAPIOutputAdapterFactory::~IAPIOutputAdapterFactory ()
{}
