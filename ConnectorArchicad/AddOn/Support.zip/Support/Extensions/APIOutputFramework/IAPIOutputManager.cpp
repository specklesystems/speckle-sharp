
#include "IAPIOutputManager.hpp"

GSAPI::IAPIOutputManager::~IAPIOutputManager ()
{}
