
#include "IAttributeProxy.hpp"


GSAPI::IAttributeProxy::~IAttributeProxy ()
{}
