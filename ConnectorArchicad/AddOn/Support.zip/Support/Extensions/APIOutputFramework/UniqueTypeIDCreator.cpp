#include "UniqueTypeIDCreator.hpp"

UInt32 GSAPI::UniqueTypeIDCreatorBase::seed = 0;
