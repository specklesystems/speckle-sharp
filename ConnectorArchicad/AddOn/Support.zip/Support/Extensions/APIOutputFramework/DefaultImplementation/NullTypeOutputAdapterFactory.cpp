
#include "NullTypeOutputAdapterFactory.hpp"

GSAPI::NullTypeOutputAdapterFactory::~NullTypeOutputAdapterFactory ()
{
}
