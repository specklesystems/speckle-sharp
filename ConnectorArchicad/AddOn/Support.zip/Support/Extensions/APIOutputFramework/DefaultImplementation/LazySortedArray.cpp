#include "LazySortedArray.hpp"

#if defined (_DUMP2XML_TRANSL)
GS::ClassInfo	GSAPI::LazySortedArrayPrivate::classInfo ("GSAPI::LazySortedArray_Dump2XML",
														 GS::Guid ("{96E52157-9A58-4510-957A-68BFC9974B25}"),
														 GS::ClassVersion (1, 0));
#else
GS::ClassInfo	GSAPI::LazySortedArrayPrivate::classInfo ("GSAPI::LazySortedArray",
														 GS::Guid ("{09EAE07E-6B5A-48EF-B8B1-7C52D8FFBEAB}"),
														 GS::ClassVersion (1, 0));
#endif