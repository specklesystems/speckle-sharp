#include "IDXFTestObject.hpp"


OD::IDXFTestObject::IDXFTestObject ()
{
}


OD::IDXFTestObject::~IDXFTestObject ()
{
}