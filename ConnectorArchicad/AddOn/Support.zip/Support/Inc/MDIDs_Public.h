#ifndef MDIDS_PUBLIC_H
#define MDIDS_PUBLIC_H

#pragma once

#define	MDID_GS1							1198731108
#define MDID_GS2							1198731090
#define	MDID_APICD							1193553710
#define	MDID_GSDEV							1193553710

#define MDID_GS1_IFC						 138575850
#define MDID_GS1_Check_Duplicates			1856978928
#define MDID_GS1_EcoDesignerStar			1250007783
#define MDID_GS2_FireRatingLabel            1917217575
#define MDID_GS2_GOFromProperty	 			3992348245
#define MDID_GS2_SolibriConnection			2426111141

#define MDID_APICD_IFCHookTest					3000989914
#define MDID_APICD_LocalEnergySimulationTest	1366129177

#endif
